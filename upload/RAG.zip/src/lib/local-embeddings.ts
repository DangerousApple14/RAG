import type { EmbedMeta } from "@/lib/vector-store";

const EMBED_DIM = 256;

export const BUILTIN_EMBED_META: EmbedMeta = {
  provider: "built-in",
  model: "hashed-ngrams-256-v1",
  baseUrl: "",
};

function fnv1a(value: string): number {
  let hash = 0x811c9dc5;
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return hash >>> 0;
}

export function hashEmbed(text: string): number[] {
  const vector = new Array<number>(EMBED_DIM).fill(0);
  const tokens = text.toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? [];
  const features = [...tokens];

  for (let i = 0; i < tokens.length - 1; i++) {
    features.push(`${tokens[i]} ${tokens[i + 1]}`);
  }

  for (const feature of features) {
    const hash = fnv1a(feature);
    const index = hash % EMBED_DIM;
    vector[index] += hash & 0x80000000 ? -1 : 1;
  }

  const magnitude = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0));
  if (magnitude > 0) {
    for (let i = 0; i < vector.length; i++) {
      vector[i] /= magnitude;
    }
  }

  return vector;
}
